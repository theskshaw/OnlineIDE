ace.define("ace/snippets/abap",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="abap"});                (function() {
                    ace.require(["ace/snippets/abap"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            