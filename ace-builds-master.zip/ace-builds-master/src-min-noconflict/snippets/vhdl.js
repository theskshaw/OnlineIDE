ace.define("ace/snippets/vhdl",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="vhdl"});                (function() {
                    ace.require(["ace/snippets/vhdl"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            